<html>
<head>

<title>Paypal </title>
</head>


<body>

<h1> Enter Values </h1>

<div class="payment">
<form action = "checkout.php" method="post" autocomplete="off">
	<label for="item"> Product 
	<input type="text" name="product">
	</label>
	<label for="amount">
		<input type="text" name="price">
		</label>
		<input type="submit" value="pay">
		</form>
		
</form>

</div>
</body>






</html>